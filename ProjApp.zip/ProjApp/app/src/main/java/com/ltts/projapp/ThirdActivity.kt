package com.ltts.projapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_home.*

class ThirdActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        var username = intent.extras?.getString("username")
        var greetings=  "Welcome $username"
        textView.setText(greetings)
        var logout = findViewById<Button>(R.id.Back2Login)
        logout.setOnClickListener{
            val intent  = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }
    }
}