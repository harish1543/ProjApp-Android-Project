package com.ltts.projapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.content.SharedPreferences
import android.widget.Button
import android.widget.CheckBox
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.reflect.Modifier

class MainActivity : AppCompatActivity() {
    lateinit var regsp:SharedPreferences
    lateinit var remember:CheckBox
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        regsp = getSharedPreferences("mypref", MODE_PRIVATE)
        var regUser = regsp.getString("username","")
        var regPass = regsp.getString("password","")
        val remCheck = findViewById<CheckBox>(R.id.checkRemember)

        var remember = regsp.getString("remember","")
        if(remember=="true")
        {
            editTextUsername.setText(regsp.getString("username",""))
            editTextPassword.setText(regsp.getString("password",""))
        }

        var buttonLogin = findViewById<Button>(R.id.buttonLogin)
        buttonLogin.setOnClickListener {

                var username = editTextUsername.text.toString()
                var password = editTextPassword.text.toString()
                if(username == regUser && password==regPass) {
                    val intent = Intent(this, ThirdActivity::class.java)
                    if(remCheck.isChecked)
                    {
                        intent.putExtra("remember","true")
                    }
                    startActivity(intent)
                }
        }
        val buttonReg = findViewById<Button>(R.id.buttonRegister)
        buttonReg.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            startActivity(intent)
        }
    }
}
