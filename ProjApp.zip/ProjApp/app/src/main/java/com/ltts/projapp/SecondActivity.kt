package com.ltts.projapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.content.SharedPreferences
import android.widget.*
import kotlinx.android.synthetic.main.activity_registration.*

class SecondActivity : AppCompatActivity() {
    lateinit var sp:SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        sp = getSharedPreferences("mypref", MODE_PRIVATE)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)
        val buttonReg = findViewById<Button>(R.id.button)
        var username = editTextUsername2.text.toString()
        var password = editTextPassword2.text.toString()
        buttonReg.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("username",username)
            intent.putExtra("password",password)
            intent.putExtra("remember","false")
            startActivity(intent)
        }


    }
}